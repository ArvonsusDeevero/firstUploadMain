using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public int attackDamage = 50;
    public float attackRange = 1f;
    public Transform attackPoint;
    public LayerMask enemyLayer;

    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Attack();  // tekan space untuk menyerang
        }
    }

    void Attack()
    {
        // Deteksi enemy di area serang
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayer);

        foreach (Collider2D enemy in hitEnemies)
        {
            enemy.GetComponent<EnemyAI>().TakeDamage(attackDamage);
        }
    }

    public void Die()
    {
        Debug.Log("Player Mati!");
        // Bisa tambahkan animasi mati di sini
        Destroy(gameObject);
    }

    // Menampilkan radius serangan di editor
    private void OnDrawGizmosSelected()
    {
        if (attackPoint == null) return;

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}
