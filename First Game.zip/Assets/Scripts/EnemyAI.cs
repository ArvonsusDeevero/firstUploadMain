using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public float speed = 2f;
    public int health = 1;

    private Transform player;

    void Start()
    {
        // mencari Player dari tag
        GameObject p = GameObject.FindGameObjectWithTag("Player");

        if (p != null)
        {
            player = p.transform;
        }
        else
        {
            Debug.LogError("Player tidak ditemukan! Pastikan object Player memiliki tag 'Player'.");
        }
    }

    void Update()
    {
        if (player == null) return;

        // Gerak menuju player
        Vector3 direction = (player.position - transform.position).normalized;
        transform.position += direction * speed * Time.deltaTime;
    }

    // ==== FUNGSI TAMBAHAN UNTUK DISERANG PLAYER ====
    public void TakeDamage(int damage)
    {
        health -= damage;

        if (health <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Destroy(gameObject);
    }

}
